from otree.api import *
from random import choice , randint

doc = """ """

class C(BaseConstants):
    NAME_IN_URL = ''
    PLAYERS_PER_GROUP = 9
    NUM_ROUNDS = 30

    Assigner_ROLE = "a"
    Green_solver1_ROLE = "g1"
    Green_solver2_ROLE = "g2"
    Green_solver3_ROLE = "g3"
    Green_solver4_ROLE = "g4"
    Blue_solver1_ROLE = "b11"
    Blue_solver2_ROLE = "b12"
    Blue_solver3_ROLE = "b21"
    Blue_solver4_ROLE = "b22"

    roles = ["g1", "g2", "g3", "g4", "b11", "b12", "b21", "b22"]

    JOB_A_SOLVER_MUL = 0.5
    JOB_B_SOLVER_MUL = 0.25
    JOB_A_ASSIGNER_MUL = 0.8 - JOB_A_SOLVER_MUL
    JOB_B_ASSIGNER_MUL = 0.5 - JOB_B_SOLVER_MUL

    TYPE_2_JOB_A_TASK_COUNT_PER_ROUND = 2
    USE_POINTS = True

    payoff = cu(100)


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    allow_type_2 = models.BooleanField(
        choices=[[True, 'Yes'], [False, 'No']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    g1 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    g2 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    g3 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    g4 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    b11 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    b12 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    b21 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    b22 = models.BooleanField(
        choices=[[True, 'Job A'], [False, 'Job B']],
        doc="""This player's decision""",
        widget=widgets.RadioSelect,
    )

    ans1 = models.IntegerField(initial=0)
    ans2 = models.IntegerField(initial=0)
    allowed = models.BooleanField(initial=True)
    job_A = models.BooleanField(initial=True)
    job_A_count = models.IntegerField(initial=0)

    num1 = models.IntegerField(initial=0)
    num2 = models.IntegerField(initial=0)
    num3 = models.IntegerField(initial=0)
    num4 = models.IntegerField(initial=0)

    job_count = models.IntegerField(initial = 0)


class Introduction(Page):
    timeout_seconds = 30
    def vars_for_template(player):
        sum1 = sum(p.payoff for p in player.in_all_rounds())
        return dict(role=player.role, points = sum1)

class VoteForType2(Page):
    form_model = 'player'
    form_fields = ['allow_type_2']

    def is_displayed(player):
        return (not player.role in ["a", "b21", "b22"])

class VotingWait(WaitPage):
    def after_all_players_arrive(group):
        vote_results = []
        for a in C.roles[:-2]:
            vote_results.append(group.get_player_by_role(a).allow_type_2)
        random_vote = choice(vote_results)
        for player in [ group.get_player_by_role(a) for a in ["b21", "b22","a"] ] :
            player.allowed = random_vote

class JobAssign(Page):
    form_model = 'player'
    def get_form_fields(player):
        if player.allowed:
            return ["g1", "g2", "g3", "g4", "b11", "b12", "b21", "b22"]
        else:
            return ["g1", "g2", "g3", "g4", "b11", "b12"]

    def is_displayed(player):
        return player.role == "a"

class WaitJobAssign(WaitPage):
    def after_all_players_arrive(group):
        assigner = group.get_player_by_role("a")
        array = [assigner.g1, assigner.g2, assigner.g3, assigner.g4, assigner.b11, assigner.b12, assigner.field_maybe_none('b21'), assigner.field_maybe_none('b22')]
        i = 0
        p = None
        while i < 8:
            p = group.get_player_by_role(C.roles[i])
            p.job_A = array[i] if array[i] != None else False
            p.num1 = randint(1,10)
            p.num2 = randint(1,10)
            p.num3 = randint(1,10)
            p.num4 = randint(1,10)
            i+=1

class JobPage(Page):
    timeout_seconds = 30
    form_model = 'player'

    def vars_for_template(player):
        if player.role not in ['b21', "b22"]:
            return dict(num1=player.num1, num2= player.num2, num3=player.num3, num4= player.num4)
        else:
            return dict(num1=player.num1, num2= player.num2, num3=player.num3, num4= player.num4)
    
    def get_form_fields(player):
        if player.role in ["b21","b22"] and player.job_A:
            return ["ans1"]
        else:
            return ["ans1"]

    def is_displayed(player):
        return (not (player.role == "a")) and player.allowed
    
    def live_method(player, data):
        if data["type"] == 'ans':
            if int(data['data']["ans"]) == player.num1 * player.num2:
                player.job_count+=1
                player.num1 = randint(1,10)
                player.num2 = randint(1,10)
                return {player.id_in_group:{"type":"reload", "data" : {"num1": player.num1, "num2": player.num2}}}
        

class WaitJob(WaitPage):
    def after_all_players_arrive(group):
        assigner = None
        job_A_count = 0
        job_B_count = 0
        for player in group.get_players():
            if player.role == "a":
                assigner = player
            elif player.job_A:
                if player.role in ["b21", "b22"]:
                    player.payoff = C.JOB_A_SOLVER_MUL * player.job_count//2
                    job_A_count+=player.job_count
                else:
                    player.payoff = C.JOB_A_SOLVER_MUL * player.job_count
                    job_A_count+=player.job_count
            else:
                player.payoff = C.JOB_B_SOLVER_MUL * player.job_count
                job_B_count+=player.job_count

        assigner.payoff = (C.JOB_A_ASSIGNER_MUL * job_A_count + C.JOB_B_ASSIGNER_MUL*job_B_count) * C.payoff

class Results(Page):
    def vars_for_template(player):
        return dict(points = player.payoff)

class FinalResults(Page):
    def vars_for_template(player):
        sum1 = sum(p.payoff for p in player.in_all_rounds())
        return dict(points = sum)
    def is_displayed(player):
        return player.round_number == 30

page_sequence = [Introduction,VoteForType2,VotingWait, JobAssign, WaitJobAssign, JobPage, WaitJob,Results,FinalResults]
        